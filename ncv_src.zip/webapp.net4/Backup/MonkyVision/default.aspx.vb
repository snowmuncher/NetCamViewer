﻿Public Class _default
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        '
        '
        '
        If IsNothing(Session("SESSIONDATE")) Then
            Session("SESSIONDATE") = Today.ToLongDateString().ToString
        Else
            Session("SESSIONDATE") = Today.ToLongDateString().ToString
        End If

    End Sub

End Class